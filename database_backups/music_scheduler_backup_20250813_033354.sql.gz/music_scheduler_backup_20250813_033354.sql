/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.22-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: music_scheduler
-- ------------------------------------------------------
-- Server version	10.6.22-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `availability`
--

DROP TABLE IF EXISTS `availability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `availability` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instructor_id` int(11) DEFAULT NULL,
  `day_of_week` int(11) DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `instructor_id` (`instructor_id`),
  CONSTRAINT `availability_ibfk_1` FOREIGN KEY (`instructor_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `availability`
--

LOCK TABLES `availability` WRITE;
/*!40000 ALTER TABLE `availability` DISABLE KEYS */;
INSERT INTO `availability` VALUES (2,2,0,'13:00:00','21:30:00'),(4,2,1,'09:30:00','12:30:00'),(5,2,2,'09:30:00','12:30:00'),(6,2,3,'09:30:00','12:30:00'),(7,2,4,'09:30:00','12:30:00'),(11,5,0,'09:00:00','21:30:00'),(12,5,1,'09:00:00','21:30:00'),(13,5,2,'09:00:00','21:30:00'),(14,5,3,'09:00:00','21:30:00'),(15,5,4,'09:00:00','21:30:00');
/*!40000 ALTER TABLE `availability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deletion_affected_data`
--

DROP TABLE IF EXISTS `deletion_affected_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `deletion_affected_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deletion_audit_id` int(11) NOT NULL,
  `affected_table` varchar(100) NOT NULL,
  `affected_record_id` int(11) NOT NULL,
  `affected_record_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`affected_record_data`)),
  `action_taken` enum('deleted','cancelled','reassigned','archived') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_deletion_audit` (`deletion_audit_id`),
  KEY `idx_affected_table` (`affected_table`),
  CONSTRAINT `deletion_affected_data_ibfk_1` FOREIGN KEY (`deletion_audit_id`) REFERENCES `user_deletion_audit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deletion_affected_data`
--

LOCK TABLES `deletion_affected_data` WRITE;
/*!40000 ALTER TABLE `deletion_affected_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `deletion_affected_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_logs`
--

DROP TABLE IF EXISTS `email_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `email_type` varchar(100) NOT NULL,
  `lesson_id` int(11) DEFAULT NULL,
  `status` enum('sent','failed','pending','skipped') NOT NULL,
  `error_message` text DEFAULT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `lesson_id` (`lesson_id`),
  CONSTRAINT `email_logs_ibfk_1` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_logs`
--

LOCK TABLES `email_logs` WRITE;
/*!40000 ALTER TABLE `email_logs` DISABLE KEYS */;
INSERT INTO `email_logs` VALUES (1,'test@example.com','Test Email','test',NULL,'skipped','Email service disabled','2025-08-13 02:53:13'),(2,'test@example.com','Test Email','test',NULL,'failed','No SMTP configuration found','2025-08-13 02:53:22');
/*!40000 ALTER TABLE `email_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_service_settings`
--

DROP TABLE IF EXISTS `email_service_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_service_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_enabled` tinyint(1) DEFAULT 1,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_service_settings`
--

LOCK TABLES `email_service_settings` WRITE;
/*!40000 ALTER TABLE `email_service_settings` DISABLE KEYS */;
INSERT INTO `email_service_settings` VALUES (1,0,'2025-08-13 02:55:55','admin');
/*!40000 ALTER TABLE `email_service_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(100) NOT NULL,
  `subject_template` text NOT NULL,
  `body_template` text NOT NULL,
  `template_type` enum('lesson_confirmation','lesson_notification','lesson_update','lesson_cancellation') NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_name` (`template_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
INSERT INTO `email_templates` VALUES (1,'lesson_confirmation_student','Lesson Confirmation - {student_name}','<div style=\"font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;\">\n    <h2 style=\"color: #2c3e50; text-align: center;\">???? Lesson Confirmation</h2>\n    <div style=\"background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;\">\n        <p>Dear <strong>{student_name}</strong>,</p>\n        <p>Your music lesson has been successfully scheduled!</p>\n        \n        <div style=\"background-color: white; padding: 15px; border-radius: 5px; margin: 15px 0;\">\n            <h3 style=\"color: #27ae60; margin-top: 0;\">Lesson Details:</h3>\n            <ul style=\"list-style: none; padding: 0;\">\n                <li><strong>???? Date:</strong> {lesson_date}</li>\n                <li><strong>???? Time:</strong> {lesson_time}</li>\n                <li><strong>⏱️ Duration:</strong> {duration} minutes</li>\n                <li><strong>???? Instrument:</strong> {instrument}</li>\n                <li><strong>????‍???? Instructor:</strong> {instructor_name}</li>\n            </ul>\n        </div>\n        \n        {lesson_notes}\n        \n        <p>If you have any questions or need to reschedule, please contact your instructor or our office.</p>\n        <p>We look forward to your lesson!</p>\n        \n        <hr style=\"margin: 20px 0; border: none; border-top: 1px solid #ddd;\">\n        <p style=\"color: #666; font-size: 12px;\">This is an automated message from the Music Scheduler system.</p>\n    </div>\n</div>','lesson_confirmation',1,'2025-08-13 02:41:55','2025-08-13 02:41:55'),(2,'lesson_notification_instructor','New Lesson Scheduled - {student_name}','<div style=\"font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;\">\n    <h2 style=\"color: #2c3e50; text-align: center;\">???? New Lesson Scheduled</h2>\n    <div style=\"background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;\">\n        <p>Hello <strong>{instructor_name}</strong>,</p>\n        <p>A new lesson has been scheduled for you:</p>\n        \n        <div style=\"background-color: white; padding: 15px; border-radius: 5px; margin: 15px 0;\">\n            <h3 style=\"color: #3498db; margin-top: 0;\">Lesson Details:</h3>\n            <ul style=\"list-style: none; padding: 0;\">\n                <li><strong>???? Student:</strong> {student_name}</li>\n                <li><strong>???? Date:</strong> {lesson_date}</li>\n                <li><strong>???? Time:</strong> {lesson_time}</li>\n                <li><strong>⏱️ Duration:</strong> {duration} minutes</li>\n                <li><strong>???? Instrument:</strong> {instrument}</li>\n            </ul>\n        </div>\n        \n        {lesson_notes}\n        \n        <p>Please make sure to prepare for this lesson. If you have any conflicts, please contact the administration immediately.</p>\n        \n        <hr style=\"margin: 20px 0; border: none; border-top: 1px solid #ddd;\">\n        <p style=\"color: #666; font-size: 12px;\">This is an automated message from the Music Scheduler system.</p>\n    </div>\n</div>','lesson_notification',1,'2025-08-13 02:41:55','2025-08-13 02:41:55'),(3,'lesson_update_notification','Lesson Updated - {student_name}','<div style=\"font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;\">\n    <h2 style=\"color: #f39c12; text-align: center;\">???? Lesson Updated</h2>\n    <div style=\"background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;\">\n        <p>Dear <strong>{recipient_name}</strong>,</p>\n        <p>Your lesson details have been updated:</p>\n        \n        <div style=\"background-color: white; padding: 15px; border-radius: 5px; margin: 15px 0;\">\n            <h3 style=\"color: #f39c12; margin-top: 0;\">Updated Lesson Details:</h3>\n            <ul style=\"list-style: none; padding: 0;\">\n                <li><strong>???? Student:</strong> {student_name}</li>\n                <li><strong>????‍???? Instructor:</strong> {instructor_name}</li>\n                <li><strong>???? Date:</strong> {lesson_date}</li>\n                <li><strong>???? Time:</strong> {lesson_time}</li>\n                <li><strong>⏱️ Duration:</strong> {duration} minutes</li>\n                <li><strong>???? Instrument:</strong> {instrument}</li>\n            </ul>\n        </div>\n        \n        {lesson_notes}\n        \n        <p>Please update your calendar with these new details. If you have any questions, please contact us.</p>\n        \n        <hr style=\"margin: 20px 0; border: none; border-top: 1px solid #ddd;\">\n        <p style=\"color: #666; font-size: 12px;\">This is an automated message from the Music Scheduler system.</p>\n    </div>\n</div>','lesson_update',1,'2025-08-13 02:41:55','2025-08-13 02:41:55'),(4,'lesson_cancellation_notification','Lesson Cancelled - {student_name}','<div style=\"font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;\">\n    <h2 style=\"color: #e74c3c; text-align: center;\">???? Lesson Cancelled</h2>\n    <div style=\"background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;\">\n        <p>Dear <strong>{recipient_name}</strong>,</p>\n        <p>We regret to inform you that the following lesson has been cancelled:</p>\n        \n        <div style=\"background-color: white; padding: 15px; border-radius: 5px; margin: 15px 0; border-left: 4px solid #e74c3c;\">\n            <h3 style=\"color: #e74c3c; margin-top: 0;\">Cancelled Lesson Details:</h3>\n            <ul style=\"list-style: none; padding: 0;\">\n                <li><strong>???? Student:</strong> {student_name}</li>\n                <li><strong>????‍???? Instructor:</strong> {instructor_name}</li>\n                <li><strong>???? Date:</strong> {lesson_date}</li>\n                <li><strong>???? Time:</strong> {lesson_time}</li>\n                <li><strong>???? Instrument:</strong> {instrument}</li>\n            </ul>\n        </div>\n        \n        <p>We apologize for any inconvenience this may cause. Please contact us to reschedule at your earliest convenience.</p>\n        \n        <hr style=\"margin: 20px 0; border: none; border-top: 1px solid #ddd;\">\n        <p style=\"color: #666; font-size: 12px;\">This is an automated message from the Music Scheduler system.</p>\n    </div>\n</div>','lesson_cancellation',1,'2025-08-13 02:41:55','2025-08-13 02:41:55');
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructor_instruments`
--

DROP TABLE IF EXISTS `instructor_instruments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructor_instruments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instructor_id` int(11) DEFAULT NULL,
  `instrument` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `instructor_id` (`instructor_id`),
  CONSTRAINT `instructor_instruments_ibfk_1` FOREIGN KEY (`instructor_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructor_instruments`
--

LOCK TABLES `instructor_instruments` WRITE;
/*!40000 ALTER TABLE `instructor_instruments` DISABLE KEYS */;
/*!40000 ALTER TABLE `instructor_instruments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructor_student_assignments`
--

DROP TABLE IF EXISTS `instructor_student_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructor_student_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instructor_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `assigned_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `assigned_by_admin_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_assignment` (`instructor_id`,`student_id`),
  KEY `student_id` (`student_id`),
  KEY `assigned_by_admin_id` (`assigned_by_admin_id`),
  CONSTRAINT `instructor_student_assignments_ibfk_1` FOREIGN KEY (`instructor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `instructor_student_assignments_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `instructor_student_assignments_ibfk_3` FOREIGN KEY (`assigned_by_admin_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructor_student_assignments`
--

LOCK TABLES `instructor_student_assignments` WRITE;
/*!40000 ALTER TABLE `instructor_student_assignments` DISABLE KEYS */;
INSERT INTO `instructor_student_assignments` VALUES (1,5,1,'2025-08-13 02:28:04',1);
/*!40000 ALTER TABLE `instructor_student_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lessons`
--

DROP TABLE IF EXISTS `lessons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lessons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `instructor_id` int(11) DEFAULT NULL,
  `lesson_date` date DEFAULT NULL,
  `lesson_time` time DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `instrument` varchar(50) DEFAULT NULL,
  `reminder_enabled` tinyint(1) DEFAULT 1,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `instructor_id` (`instructor_id`),
  CONSTRAINT `lessons_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  CONSTRAINT `lessons_ibfk_2` FOREIGN KEY (`instructor_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lessons`
--

LOCK TABLES `lessons` WRITE;
/*!40000 ALTER TABLE `lessons` DISABLE KEYS */;
INSERT INTO `lessons` VALUES (1,1,2,'2025-08-15','14:00:00',60,'Piano',1,'First lesson with Alice'),(2,4,2,'2025-08-13','14:00:00',30,'Drums',1,'practice single stroke rolls and flam taps');
/*!40000 ALTER TABLE `lessons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smtp_config`
--

DROP TABLE IF EXISTS `smtp_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `smtp_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `smtp_host` varchar(255) NOT NULL,
  `smtp_port` int(11) NOT NULL DEFAULT 587,
  `smtp_security` enum('NONE','STARTTLS','SSL') DEFAULT 'STARTTLS',
  `smtp_username` varchar(255) NOT NULL,
  `smtp_password_encrypted` text NOT NULL,
  `from_email` varchar(255) NOT NULL,
  `from_name` varchar(255) DEFAULT 'Music Scheduler',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smtp_config`
--

LOCK TABLES `smtp_config` WRITE;
/*!40000 ALTER TABLE `smtp_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `smtp_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `instrument` varchar(50) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_students_deleted` (`is_deleted`,`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,'Alice Johnson','alice@email.com','555-0101','Piano',0,NULL,NULL),(2,'Bob Smith','bob@email.com','555-0102','Guitar',0,NULL,NULL),(3,'Carol Davis','carol@email.com','555-0103','Violin',0,NULL,NULL),(4,'David Wilson','david@email.com','555-0104','Drums',0,NULL,NULL),(5,'Test Student 1','student1@example.com','555-1001','Piano',0,NULL,NULL),(6,'Test Student 2','student2@example.com','555-1002','Guitar',0,NULL,NULL);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `time_off`
--

DROP TABLE IF EXISTS `time_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `time_off` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instructor_id` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `instructor_id` (`instructor_id`),
  CONSTRAINT `time_off_ibfk_1` FOREIGN KEY (`instructor_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_off`
--

LOCK TABLES `time_off` WRITE;
/*!40000 ALTER TABLE `time_off` DISABLE KEYS */;
INSERT INTO `time_off` VALUES (1,2,'2025-08-16','2025-08-17'),(2,5,'2025-08-16','2025-08-17');
/*!40000 ALTER TABLE `time_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_deletion_audit`
--

DROP TABLE IF EXISTS `user_deletion_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_deletion_audit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted_user_id` int(11) NOT NULL,
  `deleted_username` varchar(255) NOT NULL,
  `deleted_user_role` enum('admin','instructor','student') NOT NULL,
  `deleted_user_type` enum('user','student') NOT NULL,
  `deleted_by_admin_id` int(11) NOT NULL,
  `deleted_by_admin_username` varchar(255) NOT NULL,
  `deletion_reason` text DEFAULT NULL,
  `affected_lessons_count` int(11) DEFAULT 0,
  `affected_assignments_count` int(11) DEFAULT 0,
  `affected_availability_count` int(11) DEFAULT 0,
  `related_data_summary` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`related_data_summary`)),
  `deleted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_deleted_user_id` (`deleted_user_id`),
  KEY `idx_deleted_by_admin` (`deleted_by_admin_id`),
  KEY `idx_deletion_date` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_deletion_audit`
--

LOCK TABLES `user_deletion_audit` WRITE;
/*!40000 ALTER TABLE `user_deletion_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_deletion_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'instructor',
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_users_deleted` (`is_deleted`,`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2b$12$.iXjCjpi5mHuAHeRp3waw.FsrEbAaUzov/xkLYwZS8NdjdO5XRF9u','admin',NULL,NULL,0,NULL,NULL),(2,'test','$2b$12$EB0N8qBlzvPwfJbqCFj7H.vEjLmcyYcgCh5kEJ7Al6qgqXJwwnVim','instructor',NULL,NULL,0,NULL,NULL),(4,'testadmin','$2b$12$UscD9//0W5PCVSCJD.BuvusnXT/s1oUcR6/38FzHXJ3BhFI3Na5Me','admin',NULL,NULL,0,NULL,NULL),(5,'testinstructor','$2b$12$Z3WQj29PV1lMNshAr/vNxubycvvGN8SlHj9JVPljvEF.XIvxq.lGu','instructor',NULL,NULL,0,NULL,NULL),(7,'Kelly','$2b$12$wSLg99fLwQv95RfwH4n1pO5Al3jzWa1m3ht/TQ7mAqBOULvmo86A6','admin',NULL,NULL,0,NULL,NULL),(8,'deletetest','$2b$12$JTins3Crumj0yQH5L9TSeO0bokDxZRHE4r3RVwCHQcvVE3crqI1m2','instructor','deletetest@example.com','555-0001',0,NULL,NULL),(9,'testadmin2','$2b$12$QSt7V.6yfb6P2yMxIYkipuD.vvn74jUpXX/wiiu8xNKWSirqmboca','admin','testadmin2@example.com','555-0099',0,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'music_scheduler'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-13  3:33:54
